export const preloadTemplates = async function () {
    const templatePaths = [
    // Add paths to "systems/FateExtended/templates"
    ];
    return loadTemplates(templatePaths);
};
