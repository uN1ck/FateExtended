export class FateItem extends Item {
}
