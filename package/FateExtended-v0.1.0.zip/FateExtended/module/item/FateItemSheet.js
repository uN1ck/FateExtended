export class FateItemSheet extends ItemSheet {
}
