export default class Constants {
}
Constants.MODULE_NAME = "FateExtended";
